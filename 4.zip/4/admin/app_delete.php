<?php
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

require_once __DIR__ . '/../includes/db.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    try {
        // 1. Fetch current app details to delete the logo file
        $stmt = $pdo->prepare("SELECT logo FROM apps WHERE id = ?");
        $stmt->execute([$id]);
        $app = $stmt->fetch();
        
        if ($app) {
            // Delete file if it exists
            if ($app['logo'] && file_exists('../' . $app['logo'])) {
                unlink('../' . $app['logo']);
            }
            
            // 2. Delete database entry
            $delete = $pdo->prepare("DELETE FROM apps WHERE id = ?");
            $delete->execute([$id]);
        }
    } catch (PDOException $e) {
        // Log or handle error silently, redirection handles the fallback
    }
}

header("Location: index.php?success=1");
exit;
?>
