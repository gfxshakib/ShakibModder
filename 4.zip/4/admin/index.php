<?php
require_once 'includes/header.php';

// Fetch metrics
try {
    $total_apps = $pdo->query("SELECT COUNT(*) FROM apps")->fetchColumn();
    $total_downloads = $pdo->query("SELECT SUM(downloads_count) FROM apps")->fetchColumn();
    $total_downloads = $total_downloads ? $total_downloads : 0;
    $total_categories = $pdo->query("SELECT COUNT(DISTINCT category) FROM apps")->fetchColumn();
    
    // Fetch apps list
    $stmt = $pdo->query("SELECT * FROM apps ORDER BY id DESC");
    $apps = $stmt->fetchAll();
} catch (PDOException $e) {
    $total_apps = 0;
    $total_downloads = 0;
    $total_categories = 0;
    $apps = [];
    $error = "Error fetching metrics: " . $e->getMessage();
}
?>

<!-- Metrics Overview -->
<div class="admin-metrics animated-fade">
  <div class="metric-card">
    <div class="metric-info">
      <h4>Total Applications</h4>
      <span><?php echo (int)$total_apps; ?></span>
    </div>
    <div class="metric-icon blue">📦</div>
  </div>
  
  <div class="metric-card">
    <div class="metric-info">
      <h4>Total Downloads</h4>
      <span><?php echo number_format($total_downloads); ?></span>
    </div>
    <div class="metric-icon green">↓</div>
  </div>
  
  <div class="metric-card">
    <div class="metric-info">
      <h4>Active Categories</h4>
      <span><?php echo (int)$total_categories; ?></span>
    </div>
    <div class="metric-icon pink">🗂</div>
  </div>
</div>

<!-- Apps Management Table -->
<div class="admin-card animated-fade" style="max-width: 100%;">
  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
    <h3 style="font-family: var(--font-display); font-size: 20px; font-weight: 700;">Manage Applications</h3>
    <a href="app_add.php" class="btn-submit" style="font-size: 13px; padding: 8px 16px; border-radius: var(--radius-sm);">+ Add Application</a>
  </div>
  
  <?php if (isset($_GET['success'])): ?>
    <div class="alert alert-success">Operation completed successfully.</div>
  <?php endif; ?>
  
  <?php if (isset($error)): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
  <?php endif; ?>
  
  <div class="admin-table-container">
    <table class="admin-table">
      <thead>
        <tr>
          <th>Logo</th>
          <th>App Name</th>
          <th>Category</th>
          <th>Size</th>
          <th>Version</th>
          <th>Rating</th>
          <th>Downloads</th>
          <th style="text-align: right;">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (count($apps) > 0): ?>
          <?php foreach ($apps as $app): ?>
            <tr>
              <td>
                <img class="table-logo" src="<?php echo htmlspecialchars($app['logo'] ? '../'.$app['logo'] : '../assets/images/default-logo.svg'); ?>" alt="">
              </td>
              <td style="font-weight: 600;"><?php echo htmlspecialchars($app['name']); ?></td>
              <td><?php echo htmlspecialchars($app['category']); ?></td>
              <td><?php echo htmlspecialchars($app['size']); ?></td>
              <td><code><?php echo htmlspecialchars($app['version']); ?></code></td>
              <td>★ <?php echo number_format($app['rating'], 1); ?></td>
              <td><?php echo number_format($app['downloads_count']); ?></td>
              <td style="text-align: right;">
                <a href="app_edit.php?id=<?php echo $app['id']; ?>" class="btn-action edit">Edit</a>
                <a href="app_delete.php?id=<?php echo $app['id']; ?>" class="btn-action delete" onclick="return confirm('Are you sure you want to delete this application?');">Delete</a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="8" style="text-align: center; color: var(--text-muted); padding: 32px;">No applications added yet. Click "+ Add Application" to create one.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php
require_once 'includes/footer.php';
?>
