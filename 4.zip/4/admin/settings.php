<?php
require_once 'includes/header.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    
    if ($action === 'settings') {
        $settings = [
            'site_name' => isset($_POST['site_name']) ? trim($_POST['site_name']) : 'XPDIGITAL',
            'site_tagline' => isset($_POST['site_tagline']) ? trim($_POST['site_tagline']) : '',
            'site_description' => isset($_POST['site_description']) ? trim($_POST['site_description']) : '',
            'contact_email' => isset($_POST['contact_email']) ? trim($_POST['contact_email']) : '',
            'telegram_link' => isset($_POST['telegram_link']) ? trim($_POST['telegram_link']) : '',
            'custom_head' => isset($_POST['custom_head']) ? trim($_POST['custom_head']) : '',
        ];
        
        try {
            $stmt = $pdo->prepare("INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
            foreach ($settings as $key => $value) {
                $stmt->execute([$key, $value, $value]);
            }
            $success = 'Settings updated successfully.';
        } catch (PDOException $e) {
            $error = 'Failed to update settings: ' . $e->getMessage();
        }
    } elseif ($action === 'password') {
        $curr_pass = isset($_POST['current_password']) ? trim($_POST['current_password']) : '';
        $new_pass = isset($_POST['new_password']) ? trim($_POST['new_password']) : '';
        $confirm_pass = isset($_POST['confirm_password']) ? trim($_POST['confirm_password']) : '';
        
        if ($curr_pass === '' || $new_pass === '' || $confirm_pass === '') {
            $error = 'All password fields are required.';
        } elseif ($new_pass !== $confirm_pass) {
            $error = 'New password and confirmation do not match.';
        } elseif (strlen($new_pass) < 6) {
            $error = 'New password must be at least 6 characters long.';
        } else {
            try {
                // Fetch current user details
                $stmt = $pdo->prepare("SELECT * FROM admin_users WHERE username = ?");
                $stmt->execute([$_SESSION['admin_username']]);
                $user = $stmt->fetch();
                
                if ($user && password_verify($curr_pass, $user['password'])) {
                    // Update password
                    $hashed_pass = password_hash($new_pass, PASSWORD_BCRYPT);
                    $update = $pdo->prepare("UPDATE admin_users SET password = ? WHERE id = ?");
                    $update->execute([$hashed_pass, $user['id']]);
                    
                    $success = 'Password updated successfully.';
                } else {
                    $error = 'Current password is incorrect.';
                }
            } catch (PDOException $e) {
                $error = 'Database update error: ' . $e->getMessage();
            }
        }
    }
}

// Reload configurations
$site_name = getSetting('site_name', 'XPDIGITAL');
$site_tagline = getSetting('site_tagline', '');
$site_description = getSetting('site_description', '');
$contact_email = getSetting('contact_email', '');
$telegram_link = getSetting('telegram_link', '');
$custom_head = getSetting('custom_head', '');
?>

<?php if ($success !== ''): ?>
  <div class="alert alert-success animated-fade"><?php echo htmlspecialchars($success); ?></div>
<?php endif; ?>

<?php if ($error !== ''): ?>
  <div class="alert alert-danger animated-fade"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<div class="form-row animated-fade" style="align-items: flex-start; gap: 32px;">
  
  <!-- Website Configuration Form -->
  <div class="admin-card" style="flex: 1;">
    <h3 style="font-family: var(--font-display); font-size: 20px; font-weight: 700; margin-bottom: 24px; border-bottom: 1px solid var(--border); padding-bottom: 12px;">General Settings</h3>
    
    <form action="settings.php" method="POST">
      <input type="hidden" name="action" value="settings">
      
      <div class="form-group">
        <label for="site_name">Site Name</label>
        <input type="text" name="site_name" id="site_name" class="form-control" value="<?php echo htmlspecialchars($site_name); ?>" required>
      </div>
      
      <div class="form-group">
        <label for="site_tagline">Site Tagline</label>
        <input type="text" name="site_tagline" id="site_tagline" class="form-control" value="<?php echo htmlspecialchars($site_tagline); ?>" placeholder="e.g. Fast & Secure Apps Downloader">
      </div>
      
      <div class="form-group">
        <label for="site_description">Meta Description</label>
        <textarea name="site_description" id="site_description" class="form-control" placeholder="Short description of the website used by search engines..."><?php echo htmlspecialchars($site_description); ?></textarea>
      </div>
      
      <div class="form-row">
        <div class="form-group">
          <label for="contact_email">Contact Email</label>
          <input type="email" name="contact_email" id="contact_email" class="form-control" value="<?php echo htmlspecialchars($contact_email); ?>" placeholder="support@xpdigital.shop">
        </div>
        
        <div class="form-group">
          <label for="telegram_link">Telegram Channel/Support Link</label>
          <input type="url" name="telegram_link" id="telegram_link" class="form-control" value="<?php echo htmlspecialchars($telegram_link); ?>" placeholder="https://t.me/yourchannel">
        </div>
      </div>
      
      <div class="form-group">
        <label for="custom_head">Custom Header HTML (e.g. Analytics, custom CSS, verification meta tags)</label>
        <textarea name="custom_head" id="custom_head" class="form-control" style="font-family: monospace; font-size: 13px;" placeholder="e.g. &lt;script src='...'&gt;&lt;/script&gt;"><?php echo htmlspecialchars($custom_head); ?></textarea>
      </div>
      
      <button type="submit" class="btn-submit">Save Settings</button>
    </form>
  </div>
  
  <!-- Password Configuration Form -->
  <div class="admin-card" style="width: 100%; max-width: 400px;">
    <h3 style="font-family: var(--font-display); font-size: 20px; font-weight: 700; margin-bottom: 24px; border-bottom: 1px solid var(--border); padding-bottom: 12px;">Change Password</h3>
    
    <form action="settings.php" method="POST">
      <input type="hidden" name="action" value="password">
      
      <div class="form-group">
        <label for="current_password">Current Password</label>
        <input type="password" name="current_password" id="current_password" class="form-control" required autocomplete="current-password">
      </div>
      
      <div class="form-group">
        <label for="new_password">New Password</label>
        <input type="password" name="new_password" id="new_password" class="form-control" required autocomplete="new-password">
      </div>
      
      <div class="form-group" style="margin-bottom: 32px;">
        <label for="confirm_password">Confirm New Password</label>
        <input type="password" name="confirm_password" id="confirm_password" class="form-control" required autocomplete="new-password">
      </div>
      
      <button type="submit" class="btn-submit" style="width: 100%;">Update Password</button>
    </form>
  </div>
</div>

<?php
require_once 'includes/footer.php';
?>
