<?php
require_once 'includes/header.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    header("Location: index.php");
    exit;
}

// Fetch current app details
try {
    $stmt = $pdo->prepare("SELECT * FROM apps WHERE id = ?");
    $stmt->execute([$id]);
    $app = $stmt->fetch();
    
    if (!$app) {
        header("Location: index.php");
        exit;
    }
} catch (PDOException $e) {
    die("Query failed: " . $e->getMessage());
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $category = isset($_POST['category']) ? trim($_POST['category']) : '';
    $download_link = isset($_POST['download_link']) ? trim($_POST['download_link']) : '';
    $version = isset($_POST['version']) ? trim($_POST['version']) : 'v1.0';
    $size = isset($_POST['size']) ? trim($_POST['size']) : '10 MB';
    $rating = isset($_POST['rating']) ? (float)$_POST['rating'] : 4.5;
    $short_desc = isset($_POST['short_description']) ? trim($_POST['short_description']) : '';
    $desc = isset($_POST['description']) ? trim($_POST['description']) : '';
    
    if ($name === '' || $category === '' || $download_link === '' || $short_desc === '' || $desc === '') {
        $error = 'Please fill in all required fields.';
    } else {
        $logo_path = $app['logo']; // Fallback to current logo
        
        // Handle new file upload if uploaded
        if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
            $file_tmp = $_FILES['logo']['tmp_name'];
            $file_name = $_FILES['logo']['name'];
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            
            $allowed_exts = ['jpg', 'jpeg', 'png', 'svg', 'webp'];
            
            if (!in_array($file_ext, $allowed_exts)) {
                $error = 'Invalid file extension. Allowed: jpg, jpeg, png, svg, webp.';
            } else {
                $upload_dir = '../uploads/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }
                
                $new_file_name = uniqid('logo_', true) . '.' . $file_ext;
                $target_file = $upload_dir . $new_file_name;
                
                if (move_uploaded_file($file_tmp, $target_file)) {
                    // Delete old logo file if it exists
                    if ($app['logo'] && file_exists('../' . $app['logo'])) {
                        unlink('../' . $app['logo']);
                    }
                    $logo_path = 'uploads/' . $new_file_name;
                } else {
                    $error = 'Failed to upload new logo image.';
                }
            }
        }
        
        // Update in DB if no error
        if ($error === '') {
            try {
                $stmt = $pdo->prepare("UPDATE apps SET name = ?, logo = ?, download_link = ?, category = ?, version = ?, size = ?, short_description = ?, description = ?, rating = ? WHERE id = ?");
                $stmt->execute([
                    $name,
                    $logo_path,
                    $download_link,
                    $category,
                    $version,
                    $size,
                    $short_desc,
                    $desc,
                    $rating,
                    $id
                ]);
                
                header("Location: index.php?success=1");
                exit;
            } catch (PDOException $e) {
                $error = 'Database update failed: ' . $e->getMessage();
            }
        }
    }
}
?>

<div class="admin-card animated-fade">
  <div style="margin-bottom: 24px;">
    <a href="index.php" style="color: var(--primary); font-weight: 500; font-size: 14px;">&larr; Back to Dashboard</a>
  </div>
  
  <h3 style="font-family: var(--font-display); font-size: 22px; font-weight: 700; margin-bottom: 24px;">Edit Application</h3>
  
  <?php if ($error !== ''): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
  <?php endif; ?>
  
  <form action="app_edit.php?id=<?php echo $id; ?>" method="POST" enctype="multipart/form-data">
    <div class="form-row">
      <div class="form-group">
        <label for="name">App Name *</label>
        <input type="text" name="name" id="name" class="form-control" value="<?php echo htmlspecialchars($app['name']); ?>" required>
      </div>
      
      <div class="form-group">
        <label for="category">Category *</label>
        <input type="text" name="category" id="category" class="form-control" value="<?php echo htmlspecialchars($app['category']); ?>" required list="categories-list">
        <datalist id="categories-list">
          <option value="Games">
          <option value="Apps">
          <option value="Tools">
          <option value="Social">
          <option value="Productivity">
        </datalist>
      </div>
    </div>
    
    <div class="form-row">
      <div class="form-group">
        <label for="version">Version</label>
        <input type="text" name="version" id="version" class="form-control" value="<?php echo htmlspecialchars($app['version']); ?>">
      </div>
      
      <div class="form-group">
        <label for="size">File Size</label>
        <input type="text" name="size" id="size" class="form-control" value="<?php echo htmlspecialchars($app['size']); ?>">
      </div>
    </div>
    
    <div class="form-row">
      <div class="form-group">
        <label for="rating">Rating</label>
        <input type="number" step="0.1" min="1.0" max="5.0" name="rating" id="rating" class="form-control" value="<?php echo htmlspecialchars($app['rating']); ?>">
      </div>
      
      <div class="form-group">
        <label for="logo">App Logo Image (Leave empty to keep current)</label>
        <input type="file" name="logo" id="logo" class="form-control" accept="image/*">
        <?php if ($app['logo']): ?>
          <div style="margin-top: 8px; display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 12px; color: var(--text-muted);">Current:</span>
            <img src="../<?php echo htmlspecialchars($app['logo']); ?>" alt="" style="width: 32px; height: 32px; border-radius: 6px; object-fit: cover;">
          </div>
        <?php endif; ?>
      </div>
    </div>
    
    <div class="form-group">
      <label for="download_link">Download URL *</label>
      <input type="url" name="download_link" id="download_link" class="form-control" value="<?php echo htmlspecialchars($app['download_link']); ?>" required>
    </div>
    
    <div class="form-group">
      <label for="short_description">Short Description *</label>
      <input type="text" name="short_description" id="short_description" class="form-control" value="<?php echo htmlspecialchars($app['short_description']); ?>" required maxlength="120">
    </div>
    
    <div class="form-group">
      <label for="description">Full Description *</label>
      <textarea name="description" id="description" class="form-control" required><?php echo htmlspecialchars($app['description']); ?></textarea>
    </div>
    
    <button type="submit" class="btn-submit">Save Changes</button>
  </form>
</div>

<?php
require_once 'includes/footer.php';
?>
