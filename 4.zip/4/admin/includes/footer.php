  </main> <!-- End admin-main -->
</div> <!-- End admin-layout -->

<script>
// Simple script to set active menu class based on current URL
document.addEventListener('DOMContentLoaded', () => {
  const currentUrl = window.location.pathname;
  const links = document.querySelectorAll('.admin-menu-link');
  
  links.forEach(link => {
    const href = link.getAttribute('href');
    if (href && currentUrl.includes(href)) {
      link.classList.add('active');
      
      // Update the main header title to match active item if needed
      const headerTitle = document.querySelector('.admin-header h1');
      if (headerTitle) {
        if (href.includes('index.php')) headerTitle.textContent = 'Dashboard Overview';
        if (href.includes('app_add.php')) headerTitle.textContent = 'Add Application';
        if (href.includes('app_edit.php')) headerTitle.textContent = 'Edit Application';
        if (href.includes('settings.php')) headerTitle.textContent = 'General Settings';
      }
    }
  });
});
</script>
</body>
</html>
