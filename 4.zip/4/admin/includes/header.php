<?php
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

require_once __DIR__ . '/../../includes/db.php';

$admin_user = isset($_SESSION['admin_username']) ? $_SESSION['admin_username'] : 'Admin';
$site_name = getSetting('site_name', 'XPDIGITAL');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Panel - <?php echo htmlspecialchars($site_name); ?></title>
  
  <!-- Typography -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Poppins:wght@600;700;800&display=swap" rel="stylesheet">
  
  <!-- CSS Stylesheet (Shared) -->
  <link rel="stylesheet" href="../assets/css/style.css?v=1.2">
</head>
<body style="background-color: #f8fafc;">

<div class="admin-layout">
  
  <!-- Sidebar -->
  <aside class="admin-sidebar">
    <div class="admin-logo">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 2L2 7L12 12L22 7L12 2Z" fill="#3b82f6" />
        <path d="M2 17L12 22L22 17" stroke="#3b82f6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M2 12L12 17L22 12" stroke="#3b82f6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
      </svg>
      <span><?php echo htmlspecialchars($site_name); ?></span>
    </div>
    
    <ul class="admin-menu">
      <li>
        <a href="index.php" class="admin-menu-link" id="menu-dash">
          <span>Dashboard</span>
        </a>
      </li>
      <li>
        <a href="app_add.php" class="admin-menu-link" id="menu-add">
          <span>Add New App</span>
        </a>
      </li>
      <li>
        <a href="settings.php" class="admin-menu-link" id="menu-settings">
          <span>Site Settings</span>
        </a>
      </li>
      <li style="margin-top: auto; border-top: 1px solid #334155; padding-top: 16px;">
        <a href="../index.php" class="admin-menu-link" target="_blank">
          <span>View Site &raquo;</span>
        </a>
      </li>
      <li>
        <a href="logout.php" class="admin-menu-link" style="color: #f87171;" id="menu-logout">
          <span>Logout</span>
        </a>
      </li>
    </ul>
  </aside>

  <!-- Main Content Wrapper -->
  <main class="admin-main">
    
    <header class="admin-header">
      <div>
        <h1>Dashboard</h1>
        <p style="color: var(--text-muted); font-size: 14px;">Welcome back, <strong><?php echo htmlspecialchars($admin_user); ?></strong>!</p>
      </div>
      <div style="font-size: 14px; color: var(--text-muted);">
        Server Time: <?php echo date('Y-m-d H:i'); ?>
      </div>
    </header>
