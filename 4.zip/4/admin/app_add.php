<?php
require_once 'includes/header.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $category = isset($_POST['category']) ? trim($_POST['category']) : '';
    $download_link = isset($_POST['download_link']) ? trim($_POST['download_link']) : '';
    $version = isset($_POST['version']) ? trim($_POST['version']) : 'v1.0';
    $size = isset($_POST['size']) ? trim($_POST['size']) : '10 MB';
    $rating = isset($_POST['rating']) ? (float)$_POST['rating'] : 4.5;
    $short_desc = isset($_POST['short_description']) ? trim($_POST['short_description']) : '';
    $desc = isset($_POST['description']) ? trim($_POST['description']) : '';
    
    // Validate inputs
    if ($name === '' || $category === '' || $download_link === '' || $short_desc === '' || $desc === '') {
        $error = 'Please fill in all required fields.';
    } else {
        $logo_path = '';
        
        // Handle file upload
        if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
            $file_tmp = $_FILES['logo']['tmp_name'];
            $file_name = $_FILES['logo']['name'];
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            
            $allowed_exts = ['jpg', 'jpeg', 'png', 'svg', 'webp'];
            
            if (!in_array($file_ext, $allowed_exts)) {
                $error = 'Invalid file extension. Allowed: jpg, jpeg, png, svg, webp.';
            } else {
                $upload_dir = '../uploads/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }
                
                $new_file_name = uniqid('logo_', true) . '.' . $file_ext;
                $target_file = $upload_dir . $new_file_name;
                
                if (move_uploaded_file($file_tmp, $target_file)) {
                    $logo_path = 'uploads/' . $new_file_name;
                } else {
                    $error = 'Failed to upload logo image.';
                }
            }
        }
        
        // Save to DB if no error
        if ($error === '') {
            try {
                $stmt = $pdo->prepare("INSERT INTO apps (name, logo, download_link, category, version, size, short_description, description, rating, downloads_count) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)");
                $stmt->execute([
                    $name,
                    $logo_path,
                    $download_link,
                    $category,
                    $version,
                    $size,
                    $short_desc,
                    $desc,
                    $rating
                ]);
                
                header("Location: index.php?success=1");
                exit;
            } catch (PDOException $e) {
                $error = 'Database insert failed: ' . $e->getMessage();
            }
        }
    }
}
?>

<div class="admin-card animated-fade">
  <div style="margin-bottom: 24px;">
    <a href="index.php" style="color: var(--primary); font-weight: 500; font-size: 14px;">&larr; Back to Dashboard</a>
  </div>
  
  <h3 style="font-family: var(--font-display); font-size: 22px; font-weight: 700; margin-bottom: 24px;">Add New Application</h3>
  
  <?php if ($error !== ''): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
  <?php endif; ?>
  
  <form action="app_add.php" method="POST" enctype="multipart/form-data">
    <div class="form-row">
      <div class="form-group">
        <label for="name">App Name *</label>
        <input type="text" name="name" id="name" class="form-control" placeholder="e.g. WhatsApp Messenger" required>
      </div>
      
      <div class="form-group">
        <label for="category">Category *</label>
        <input type="text" name="category" id="category" class="form-control" placeholder="e.g. Social, Games, Tools" required list="categories-list">
        <datalist id="categories-list">
          <option value="Games">
          <option value="Apps">
          <option value="Tools">
          <option value="Social">
          <option value="Productivity">
        </datalist>
      </div>
    </div>
    
    <div class="form-row">
      <div class="form-group">
        <label for="version">Version</label>
        <input type="text" name="version" id="version" class="form-control" placeholder="e.g. v2.4.1" value="v1.0">
      </div>
      
      <div class="form-group">
        <label for="size">File Size</label>
        <input type="text" name="size" id="size" class="form-control" placeholder="e.g. 45 MB" value="10 MB">
      </div>
    </div>
    
    <div class="form-row">
      <div class="form-group">
        <label for="rating">Initial Rating</label>
        <input type="number" step="0.1" min="1.0" max="5.0" name="rating" id="rating" class="form-control" value="4.5">
      </div>
      
      <div class="form-group">
        <label for="logo">App Logo Image *</label>
        <input type="file" name="logo" id="logo" class="form-control" accept="image/*" required>
      </div>
    </div>
    
    <div class="form-group">
      <label for="download_link">Download URL *</label>
      <input type="url" name="download_link" id="download_link" class="form-control" placeholder="https://example.com/download/file.apk" required>
    </div>
    
    <div class="form-group">
      <label for="short_description">Short Description *</label>
      <input type="text" name="short_description" id="short_description" class="form-control" placeholder="A single line summary shown on home cards (max 120 chars)" required maxlength="120">
    </div>
    
    <div class="form-group">
      <label for="description">Full Description *</label>
      <textarea name="description" id="description" class="form-control" placeholder="Describe the application features, release notes, or dynamic instructions here..." required></textarea>
    </div>
    
    <button type="submit" class="btn-submit">Add Application</button>
  </form>
</div>

<?php
require_once 'includes/footer.php';
?>
