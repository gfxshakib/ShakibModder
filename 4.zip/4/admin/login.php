<?php
session_start();
require_once __DIR__ . '/../includes/db.php';

// If already logged in, redirect to index
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: index.php");
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    
    if ($username === '' || $password === '') {
        $error = 'Please fill in all fields.';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT * FROM admin_users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['admin_username'] = $user['username'];
                $_SESSION['admin_id'] = $user['id'];
                
                header("Location: index.php");
                exit;
            } else {
                $error = 'Invalid username or password.';
            }
        } catch (PDOException $e) {
            $error = 'Database error. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login - XPDIGITAL</title>
  
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Poppins:wght@700;800&display=swap" rel="stylesheet">
  
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="login-body">

<div class="login-card animated-fade">
  <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-bottom: 16px;">
    <path d="M12 2L2 7L12 12L22 7L12 2Z" fill="#2563eb" />
    <path d="M2 17L12 22L22 17" stroke="#2563eb" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
    <path d="M2 12L12 17L22 12" stroke="#2563eb" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
  </svg>
  <h2>Admin Panel</h2>
  <p>Sign in to manage downloads and configuration</p>
  
  <?php if ($error !== ''): ?>
    <div class="alert alert-danger" style="text-align: left;"><?php echo htmlspecialchars($error); ?></div>
  <?php endif; ?>
  
  <form action="login.php" method="POST">
    <div class="form-group" style="text-align: left;">
      <label for="username">Username</label>
      <input type="text" name="username" id="username" class="form-control" placeholder="Enter username" required autocomplete="username">
    </div>
    
    <div class="form-group" style="text-align: left; margin-bottom: 32px;">
      <label for="password">Password</label>
      <input type="password" name="password" id="password" class="form-control" placeholder="Enter password" required autocomplete="current-password">
    </div>
    
    <button type="submit" class="btn-submit" style="width: 100%;">Sign In</button>
  </form>
  
  <div style="margin-top: 24px;">
    <a href="../index.php" style="font-size: 13px; color: var(--text-muted);">&larr; Back to Main Website</a>
  </div>
</div>

</body>
</html>
