</main> <!-- End container -->

<footer>
  <div class="container">
    <div class="footer-logo">
      <span><?php echo htmlspecialchars(getSetting('site_name', 'XPDIGITAL')); ?></span>
    </div>
    <p>&copy; <?php echo date('Y'); ?> <?php echo htmlspecialchars(getSetting('site_name', 'XPDIGITAL')); ?>. All rights reserved.</p>
    <p style="margin-top: 8px; font-size: 13px; color: var(--text-muted);">
      For inquiries contact us at: <a href="mailto:<?php echo htmlspecialchars(getSetting('contact_email', 'support@xpdigital.shop')); ?>" style="color: var(--primary);"><?php echo htmlspecialchars(getSetting('contact_email', 'support@xpdigital.shop')); ?></a>
    </p>
  </div>
</footer>

<script src="assets/js/main.js"></script>
</body>
</html>
