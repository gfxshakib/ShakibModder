<?php
require_once __DIR__ . '/db.php';

// Fetch global site settings
$site_name = getSetting('site_name', 'XPDIGITAL');
$site_tagline = getSetting('site_tagline', 'Premium App Downloader');
$site_description = getSetting('site_description', 'Free and secure downloader for mobile and desktop applications.');
$custom_head = getSetting('custom_head', '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo htmlspecialchars($site_name); ?> - <?php echo htmlspecialchars($site_tagline); ?></title>
  <meta name="description" content="<?php echo htmlspecialchars($site_description); ?>">
  
  <!-- Typography & Icons -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Poppins:wght@600;700;800&display=swap" rel="stylesheet">
  
  <!-- CSS Stylesheet -->
  <link rel="stylesheet" href="assets/css/style.css?v=1.2">
  
  <?php echo $custom_head; ?>
</head>
<body>

<header class="navbar-container">
  <div class="container navbar">
    <a href="index.php" class="logo" id="site-logo">
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 2L2 7L12 12L22 7L12 2Z" fill="url(#logoGrad)" />
        <path d="M2 17L12 22L22 17" stroke="url(#logoGrad)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M2 12L12 17L22 12" stroke="url(#logoGrad)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
        <defs>
          <linearGradient id="logoGrad" x1="2" y1="2" x2="22" y2="22" gradientUnits="userSpaceOnUse">
            <stop stop-color="#2563eb" />
            <stop offset="1" stop-color="#f43f5e" />
          </linearGradient>
        </defs>
      </svg>
      <span><?php echo htmlspecialchars($site_name); ?></span>
    </a>
    
    <button class="menu-toggle" id="menu-toggle" aria-label="Toggle Navigation">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <line x1="3" y1="12" x2="21" y2="12"></line>
        <line x1="3" y1="6" x2="21" y2="6"></line>
        <line x1="3" y1="18" x2="21" y2="18"></line>
      </svg>
    </button>
    
    <nav>
      <ul class="nav-links">
        <li><a href="index.php" id="nav-home">Home</a></li>
        <li><a href="index.php?category=Games" id="nav-games">Games</a></li>
        <li><a href="index.php?category=Apps" id="nav-apps">Apps</a></li>
        <li><a href="<?php echo htmlspecialchars(getSetting('telegram_link', 'https://t.me/')); ?>" target="_blank" id="nav-support">Support</a></li>
      </ul>
    </nav>
    
    <!-- Removed admin button for privacy -->
  </div>
</header>

<main class="container">
