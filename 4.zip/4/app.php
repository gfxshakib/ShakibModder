<?php
require_once 'includes/db.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    header("Location: index.php");
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT * FROM apps WHERE id = ?");
    $stmt->execute([$id]);
    $app = $stmt->fetch();
    
    if (!$app) {
        header("Location: index.php");
        exit;
    }
} catch (PDOException $e) {
    die("Database query error: " . $e->getMessage());
}

require_once 'includes/header.php';

$logo = htmlspecialchars($app['logo'] ? $app['logo'] : 'assets/images/default-logo.svg');
$name = htmlspecialchars($app['name']);
$cat = htmlspecialchars($app['category']);
$version = htmlspecialchars($app['version']);
$size = htmlspecialchars($app['size']);
$rating = number_format($app['rating'], 1);
$downloads = number_format($app['downloads_count']);
$desc = htmlspecialchars($app['description']);
?>

<div class="app-detail-container animated-fade">
  <!-- Breadcrumbs -->
  <div class="app-breadcrumb">
    <a href="index.php">Home</a> &nbsp;&raquo;&nbsp; 
    <a href="index.php?category=<?php echo urlencode($cat); ?>"><?php echo $cat; ?></a> &nbsp;&raquo;&nbsp; 
    <span><?php echo $name; ?></span>
  </div>
  
  <div class="app-detail-card">
    <div class="app-detail-header">
      <img class="app-detail-logo" src="<?php echo $logo; ?>" alt="<?php echo $name; ?> logo">
      
      <div class="app-detail-main">
        <h1 class="app-detail-title"><?php echo $name; ?></h1>
        <span class="app-detail-category"><?php echo $cat; ?></span>
        
        <div class="app-stats-row">
          <div class="stat-box" style="border-right: 1px solid var(--border); padding-right: 24px;">
            <span class="stat-box-value">★ <?php echo $rating; ?></span>
            <span>Rating</span>
          </div>
          <div class="stat-box" style="border-right: 1px solid var(--border); padding-right: 24px;">
            <span class="stat-box-value">↓ <?php echo $downloads; ?></span>
            <span>Downloads</span>
          </div>
          <div class="stat-box" style="border-right: 1px solid var(--border); padding-right: 24px;">
            <span class="stat-box-value"><?php echo $size; ?></span>
            <span>Size</span>
          </div>
          <div class="stat-box">
            <span class="stat-box-value"><?php echo $version; ?></span>
            <span>Version</span>
          </div>
        </div>
      </div>
      
      <div class="app-detail-actions">
        <a href="download.php?id=<?php echo $id; ?>" class="btn-download-now">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>
          </svg>
          Download Now
        </a>
      </div>
    </div>
    
    <div class="app-detail-body">
      <h3>About this Application</h3>
      <div class="app-detail-desc"><?php echo nl2br($desc); ?></div>
    </div>
  </div>
</div>

<?php
require_once 'includes/footer.php';
?>
