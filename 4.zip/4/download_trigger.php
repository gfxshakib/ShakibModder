<?php
require_once 'includes/db.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    header("Location: index.php");
    exit;
}

try {
    // 1. Fetch download link
    $stmt = $pdo->prepare("SELECT download_link FROM apps WHERE id = ?");
    $stmt->execute([$id]);
    $app = $stmt->fetch();
    
    if ($app) {
        // 2. Increment download count
        $update = $pdo->prepare("UPDATE apps SET downloads_count = downloads_count + 1 WHERE id = ?");
        $update->execute([$id]);
        
        // 3. Redirect to the link
        header("Location: " . $app['download_link']);
        exit;
    } else {
        header("Location: index.php");
        exit;
    }
} catch (PDOException $e) {
    header("Location: index.php");
    exit;
}
?>
