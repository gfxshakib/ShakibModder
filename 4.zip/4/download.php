<?php
require_once 'includes/db.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    header("Location: index.php");
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT name, download_link FROM apps WHERE id = ?");
    $stmt->execute([$id]);
    $app = $stmt->fetch();
    
    if (!$app) {
        header("Location: index.php");
        exit;
    }
} catch (PDOException $e) {
    die("Database query error: " . $e->getMessage());
}

require_once 'includes/header.php';
$name = htmlspecialchars($app['name']);
?>

<div class="download-page animated-fade">
  <h1 style="font-family: var(--font-display); font-size: 28px; font-weight: 800; margin-bottom: 8px;">Preparing Your Download</h1>
  <p style="color: var(--text-muted);">Thank you for downloading <?php echo $name; ?>. Your files are compiling.</p>
  
  <div class="countdown-box">
    <svg class="countdown-circle">
      <circle class="bg-ring" cx="80" cy="80" r="72" />
      <circle class="progress-ring" id="progress-ring" cx="80" cy="80" r="72" />
    </svg>
    <div class="countdown-text" id="countdown-text">5</div>
  </div>
  
  <div class="download-status" id="status-text">Your download will start in 5 seconds...</div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const text = document.getElementById('countdown-text');
  const ring = document.getElementById('progress-ring');
  const statusText = document.getElementById('status-text');
  
  const radius = 72;
  const circumference = radius * 2 * Math.PI;
  
  ring.style.strokeDasharray = `${circumference} ${circumference}`;
  ring.style.strokeDashoffset = 0;
  
  function setProgress(percent) {
    const offset = circumference - (percent / 100) * circumference;
    ring.style.strokeDashoffset = offset;
  }
  
  let count = 5;
  setProgress(100);
  
  const interval = setInterval(() => {
    count--;
    text.textContent = count;
    setProgress((count / 5) * 100);
    
    if (count <= 0) {
      clearInterval(interval);
      statusText.innerHTML = 'Starting download... <br><span style="font-size:14px; font-weight:400;">If it does not start in a few seconds, <a href="download_trigger.php?id=<?php echo $id; ?>" style="color: var(--primary); font-weight:600; text-decoration:underline;">click here to trigger manually</a>.</span>';
      
      // Redirect to actual file trigger
      setTimeout(() => {
        window.location.href = 'download_trigger.php?id=<?php echo $id; ?>';
      }, 500);
    } else {
      statusText.textContent = `Your download will start in ${count} seconds...`;
    }
  }, 1000);
});
</script>
<?php
require_once 'includes/footer.php';
?>
