<?php
require_once 'includes/db.php';
require_once 'includes/header.php';

// Get active category from URL if present
$selected_category = isset($_GET['category']) ? trim($_GET['category']) : 'all';

// Fetch distinct categories and their counts
try {
    $cat_stmt = $pdo->query("SELECT category, COUNT(*) as count FROM apps GROUP BY category ORDER BY category ASC");
    $db_categories = $cat_stmt->fetchAll();
} catch (PDOException $e) {
    $db_categories = [];
}

// Fetch featured apps (e.g., top rated or most downloaded)
try {
    $feat_stmt = $pdo->query("SELECT * FROM apps ORDER BY downloads_count DESC, rating DESC LIMIT 5");
    $featured_apps = $feat_stmt->fetchAll();
} catch (PDOException $e) {
    $featured_apps = [];
}
?>

<div class="hero animated-fade">
  <h1>Download the Best <span>Apps & Games</span></h1>
  <p><?php echo htmlspecialchars(getSetting('site_tagline', 'High-speed downloads, secure files, and zero ads.')); ?></p>
  
  <div class="search-wrapper">
    <svg class="search-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M21 21L15 15M17 10C17 13.866 13.866 17 10 17C6.13401 17 3 13.866 3 10C3 6.13401 6.13401 3 10 3C13.866 3 17 6.13401 17 10Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
    <input type="text" class="search-input" id="search-input" placeholder="Search applications, utilities, games..." autocomplete="off">
  </div>
  
  <div class="categories-tabs">
    <button class="category-tab <?php echo $selected_category === 'all' ? 'active' : ''; ?>" data-category="all">All</button>
    <?php
    $categories_list = ['Games', 'Apps', 'Tools', 'Social', 'Productivity'];
    // Merge database categories to ensure everything is covered
    foreach ($db_categories as $db_cat) {
        if (!in_array($db_cat['category'], $categories_list)) {
            $categories_list[] = $db_cat['category'];
        }
    }
    
    foreach ($categories_list as $cat) {
        $active_class = (strcasecmp($selected_category, $cat) === 0) ? 'active' : '';
        echo '<button class="category-tab ' . $active_class . '" data-category="' . htmlspecialchars($cat) . '">' . htmlspecialchars($cat) . '</button>';
    }
    ?>
  </div>
</div>

<div class="main-content">
  <!-- Left Side: App Cards Grid -->
  <section class="apps-section">
    <h2>All Applications</h2>
    <div class="apps-grid" id="apps-grid">
      <!-- Loaded dynamically via JS, fallback below if JS disabled -->
      <?php
      // Fallback server-side rendering for search.php
      $_GET['q'] = '';
      $_GET['category'] = $selected_category;
      include 'search.php';
      ?>
    </div>
  </section>
  
  <!-- Right Side: Sidebar -->
  <aside class="sidebar">
    <!-- Featured Apps -->
    <div class="sidebar-widget">
      <h3>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
        </svg>
        Featured Downloads
      </h3>
      <div class="featured-list">
        <?php if (count($featured_apps) > 0): ?>
          <?php foreach ($featured_apps as $f_app): ?>
            <a href="app.php?id=<?php echo (int)$f_app['id']; ?>" class="featured-item">
              <img class="featured-logo" src="<?php echo htmlspecialchars($f_app['logo'] ? $f_app['logo'] : 'assets/images/default-logo.svg'); ?>" alt="<?php echo htmlspecialchars($f_app['name']); ?>">
              <div class="featured-details">
                <div class="featured-title"><?php echo htmlspecialchars($f_app['name']); ?></div>
                <div class="featured-category"><?php echo htmlspecialchars($f_app['category']); ?></div>
              </div>
              <div class="featured-download">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M12 5v14M19 12l-7 7-7-7"/>
                </svg>
                <span><?php echo number_format($f_app['downloads_count']); ?></span>
              </div>
            </a>
          <?php endforeach; ?>
        <?php else: ?>
          <p style="font-size: 13px; color: var(--text-muted);">No featured applications available.</p>
        <?php endif; ?>
      </div>
    </div>
    
    <!-- Category Counts Widget -->
    <div class="sidebar-widget">
      <h3>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <rect x="3" y="3" width="7" height="9"></rect>
          <rect x="14" y="3" width="7" height="5"></rect>
          <rect x="14" y="12" width="7" height="9"></rect>
          <rect x="3" y="16" width="7" height="5"></rect>
        </svg>
        Categories
      </h3>
      <div class="featured-list">
        <?php if (count($db_categories) > 0): ?>
          <?php foreach ($db_categories as $db_cat): ?>
            <a href="index.php?category=<?php echo urlencode($db_cat['category']); ?>" class="featured-item" style="border: none; padding-bottom: 4px;">
              <div class="featured-details">
                <div class="featured-title" style="font-weight: 500; font-size: 14px;"><?php echo htmlspecialchars($db_cat['category']); ?></div>
              </div>
              <span class="btn-card-download" style="padding: 2px 8px; font-size: 11px; border-radius: 50px;">
                <?php echo (int)$db_cat['count']; ?>
              </span>
            </a>
          <?php endforeach; ?>
        <?php else: ?>
          <p style="font-size: 13px; color: var(--text-muted);">No categories created yet.</p>
        <?php endif; ?>
      </div>
    </div>
  </aside>
</div>

<?php
require_once 'includes/footer.php';
?>
