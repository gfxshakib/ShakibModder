<?php
require_once 'includes/db.php';

$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$category = isset($_GET['category']) ? trim($_GET['category']) : 'all';

$sql = "SELECT * FROM apps WHERE 1=1";
$params = [];

if ($category !== 'all') {
    $sql .= " AND category = :category";
    $params['category'] = $category;
}

if ($q !== '') {
    $sql .= " AND (name LIKE :query OR short_description LIKE :query OR description LIKE :query)";
    $params['query'] = '%' . $q . '%';
}

$sql .= " ORDER BY id DESC";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $apps = $stmt->fetchAll();
    
    if (count($apps) > 0) {
        foreach ($apps as $app) {
            $app_id = (int)$app['id'];
            $logo = htmlspecialchars($app['logo'] ? $app['logo'] : 'assets/images/default-logo.svg');
            $name = htmlspecialchars($app['name']);
            $cat = htmlspecialchars($app['category']);
            $short_desc = htmlspecialchars($app['short_description']);
            $size = htmlspecialchars($app['size']);
            $downloads = number_format($app['downloads_count']);
            $rating = number_format($app['rating'], 1);
            
            echo '
            <article class="app-card animated-fade">
                <div class="app-card-header">
                    <img class="app-card-logo" src="' . $logo . '" alt="' . $name . ' logo">
                    <div class="app-card-meta">
                        <h3 class="app-card-title">' . $name . '</h3>
                        <div class="app-card-category">' . $cat . '</div>
                    </div>
                </div>
                <p class="app-card-desc">' . $short_desc . '</p>
                <div class="app-card-footer">
                    <div class="app-card-info">
                        <span title="Rating">★ ' . $rating . '</span>
                        <span title="Downloads">↓ ' . $downloads . '</span>
                        <span>' . $size . '</span>
                    </div>
                    <a class="btn-card-download" href="app.php?id=' . $app_id . '">View</a>
                </div>
            </article>';
        }
    } else {
        echo '<p style="grid-column: 1/-1; text-align: center; color: var(--text-muted); padding: 40px 0; font-size: 15px;">No applications found matching your criteria.</p>';
    }
} catch (PDOException $e) {
    echo '<p style="grid-column: 1/-1; text-align: center; color: var(--accent); padding: 40px 0;">Error processing request.</p>';
}
?>
