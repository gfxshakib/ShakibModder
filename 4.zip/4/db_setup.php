<?php
require_once 'includes/db.php';

$sql = <<<SQL
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- Admin users table
CREATE TABLE IF NOT EXISTS `admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Site settings key-value table
CREATE TABLE IF NOT EXISTS `site_settings` (
  `setting_key` varchar(50) NOT NULL,
  `setting_value` text DEFAULT NULL,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Applications table
CREATE TABLE IF NOT EXISTS `apps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `download_link` text NOT NULL,
  `category` varchar(100) NOT NULL,
  `version` varchar(50) NOT NULL DEFAULT 'v1.0',
  `size` varchar(50) NOT NULL DEFAULT '10 MB',
  `short_description` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `rating` decimal(3,2) NOT NULL DEFAULT 4.50,
  `downloads_count` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

COMMIT;
SQL;

try {
    // 1. Execute DDL
    $pdo->exec($sql);
    
    // 2. Insert Default Admin User
    $check_admin = $pdo->query("SELECT COUNT(*) FROM admin_users")->fetchColumn();
    if ($check_admin == 0) {
        $admin_pass = password_hash('XpDigital@2026', PASSWORD_BCRYPT);
        $ins_admin = $pdo->prepare("INSERT INTO admin_users (username, password) VALUES ('admin', ?)");
        $ins_admin->execute([$admin_pass]);
    }
    
    // 3. Insert Default Settings
    $default_settings = [
        'site_name' => 'XPDIGITAL',
        'site_tagline' => 'Professional App Downloader Platform',
        'site_description' => 'Download your favorite apps and games with high-speed download mirrors.',
        'contact_email' => 'support@xpdigital.jhxpro.shop',
        'telegram_link' => 'https://t.me/xpdigital',
        'custom_head' => ''
    ];
    
    $ins_setting = $pdo->prepare("INSERT IGNORE INTO site_settings (setting_key, setting_value) VALUES (?, ?)");
    foreach ($default_settings as $key => $value) {
        $ins_setting->execute([$key, $value]);
    }
    
    echo "Database setup completed successfully. This file is now deleting itself for safety.";
    
    // Self-destruct
    unlink(__FILE__);
} catch (\PDOException $e) {
    echo "Error setting up database: " . $e->getMessage();
}
?>
