document.addEventListener('DOMContentLoaded', () => {
  const searchInput = document.getElementById('search-input');
  const categoryTabs = document.querySelectorAll('.category-tab');
  const appsGrid = document.getElementById('apps-grid');
  
  let currentSearch = '';
  let currentCategory = 'all';
  
  // Update grid content based on query and category
  async function fetchApps() {
    if (!appsGrid) return;
    
    // Show smooth loader state
    appsGrid.style.opacity = '0.5';
    
    try {
      const params = new URLSearchParams({
        q: currentSearch,
        category: currentCategory
      });
      
      const response = await fetch(`search.php?${params.toString()}`);
      if (!response.ok) throw new Error('Network error');
      
      const html = await response.text();
      
      // Update DOM
      appsGrid.innerHTML = html;
      appsGrid.style.opacity = '1';
    } catch (error) {
      console.error('Error fetching apps:', error);
      appsGrid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: var(--accent); padding: 40px 0;">Failed to load apps. Please try again.</p>';
      appsGrid.style.opacity = '1';
    }
  }

  // Handle Search Input (with debounce)
  let debounceTimeout;
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      currentSearch = e.target.value;
      clearTimeout(debounceTimeout);
      debounceTimeout = setTimeout(() => {
        fetchApps();
      }, 300);
    });
  }

  // Handle Category Clicks
  categoryTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      categoryTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      currentCategory = tab.dataset.category || 'all';
      fetchApps();
    });
  });

  // Toggle Mobile Navigation Menu
  const menuToggle = document.getElementById('menu-toggle');
  const navLinks = document.querySelector('.nav-links');
  
  if (menuToggle && navLinks) {
    menuToggle.addEventListener('click', () => {
      navLinks.classList.toggle('show');
      const isOpen = navLinks.classList.contains('show');
      menuToggle.innerHTML = isOpen 
        ? `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
           </svg>`
        : `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <line x1="3" y1="12" x2="21" y2="12"></line>
            <line x1="3" y1="6" x2="21" y2="6"></line>
            <line x1="3" y1="18" x2="21" y2="18"></line>
           </svg>`;
    });
    
    // Close menu if a link is clicked
    const links = navLinks.querySelectorAll('a');
    links.forEach(link => {
      link.addEventListener('click', () => {
        navLinks.classList.remove('show');
      });
    });
  }
});
